const ecc = require('eosjs-ecc')


ecc.randomKey().then(privateKey => {
//console.log('Private Key:\t', privateKey) // wif
//console.log('Public Key:\t', ecc.privateToPublic(privateKey)) // EOSkey...
    
    const data = "1111";
    const res = ecc.sign(data, privateKey);

    console.log('===== res ====: ', res);
});


